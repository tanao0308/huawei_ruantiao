#include <bits/stdc++.h>
#include "global.h"